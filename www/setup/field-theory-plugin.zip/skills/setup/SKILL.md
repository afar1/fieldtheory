---
name: setup
description: Set up this Mac with Field Theory for support calls, check existing readiness, repair interrupted onboarding, prepare Parakeet, and optionally install Builder tools. Use for set up my computer, onboard my Mac, or Field Theory recording setup.
---

# Set up this Mac

Prioritize a working support call over the fewest clicks. Preserve existing apps, accounts, recording sources, hotkeys, assistant configuration and unrelated work.

## Establish the actual host

First determine whether this session can execute local tools on the user's Mac. A cloud container or Claude VM is not the user's Mac. If local tools are unavailable, explain how to open a supported local desktop session. Do not claim an official plugin listing exists: this package is a local preview. ChatGPT local MCP publication requires partner approval. Claude local MCP requires a supported local Cowork/Code session. Installing this plugin does not enable computer use.

Call `get_setup_status`. This works without the `ft` CLI. Distinguish installed, configured, verified and unknown. `helper: unavailable` means launch Field Theory and retry, not ready. `app-update-required` means the running app lacks this preview endpoint; explain that a supplied preview app is required. Never overwrite the user's installed app without explaining that change. Onboarding helpers connect only to loopback and never return credentials or library content.

If the server cannot start, run the bundled `scripts/check-setup.sh` on the local Mac. It uses only the Mac's shell and reports prerequisites without reading private content. `scripts/launch-mcp.sh` locates existing Node; if none is usable, guide installation of Node LTS from https://nodejs.org/en/download and reconnect/restart the plugin. Do not install all Builder tools just to start setup. No `ft` command is needed for these setup tools. Other library tools may require `ft`.

## Complete only missing essentials

1. If Field Theory is missing, use the supplied Onboard preview app's essentials installer, or the signed Field Theory download from https://fieldtheory.dev/. A download is not an installation or runtime test. Keep one installer owner; do not run competing installers.
2. If the account is not signed in, call `setup_action` with `open-account`. Have the user verify in Field Theory or its trusted sign-in page. Never collect passwords, email codes, tokens or authentication secrets in chat. Recheck status when they return. Account sign-in does not grant access to other people's private River content.
3. If local transcription needs preparation, call `prepare-parakeet`. It starts a background job; recheck status at reasonable intervals, not a tight polling loop. Install Python only if the app requires it. If errors persist, open `open-transcription` and explain the observed problem rather than repeating downloads.
4. For missing Mac approvals, open `open-permissions` and guide one human action at a time. Never bypass privacy controls or approve them through computer use. If the user wants both sides of a call, ask which voices to record, then call `set-recording-source` with their chosen `source`: `system-audio` for the helper, `microphone-and-system-audio` for both, or `microphone` for just the user. Never change an existing source without that choice. Keep the existing hotkey. `open-onboarding` opens the native guided setup.
5. Enable the chosen assistant's own computer-use integration using its supported controls. Its permissions differ from Field Theory's. Never infer computer-use readiness from a plist, an app's existence, or this status endpoint.

## Verify the support-call outcome

Use the assistant's actual host computer-use tool to take a screenshot and perform a harmless user-approved action, such as opening a blank document. If the tool is absent, say computer use is unavailable in this session and give the next step. Never label it verified based on filesystem checks.

Ask the user to record a short instruction with their helper speaking through the call, stop with the configured shortcut, inspect the transcript, and paste it here. For mixed audio, test both voices. Do not start recording silently. Model verification alone does not prove call audio, the hotkey, or transcript handoff. Recheck setup status and distinguish what the app reports from what this real exercise proved.

Report a short list: working, needs your action, and unverified. Setup is complete only after computer control and the call/transcription/handoff exercise pass. The user may pause and return: rerun status rather than resetting settings or installing again.

## Optional Builder

Only after essentials work, offer Builder from https://onboard.computer/builder.onboard. Explain the plan and wait for the user's choice. Reuse the Onboard app's installer and checks; do not independently execute YAML text as shell or install optional tools during essentials. If Onboard is unavailable, provide its download and keep Builder pending.
