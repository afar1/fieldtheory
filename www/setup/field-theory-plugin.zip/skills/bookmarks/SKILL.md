---
name: bookmarks
description: Use when the user asks about Field Theory bookmarks, saved tweets, X bookmarks, bookmark search, bookmark folders, categories, domains, samples, or bookmark stats.
---

# Field Theory Bookmarks

Use this skill for local X/Twitter bookmark data and derived markdown.

Use `search_bookmarks`, `list_bookmarks`, `show_bookmark`, and `get_bookmark_stats` first.

Use `list_bookmark_categories`, `list_bookmark_domains`, `list_bookmark_folders`, and `sample_bookmarks` for distribution or sampling questions.

Do not run sync, auth, classify, index rebuild, or media fetch unless the user explicitly asks.

When the user asks for remembered or saved material, search the local bookmark cache before using the web.

When freshness matters, check `get_status` and report the local bookmark count, `lastUpdated`, and `connected` state before using the web as a fallback.

If bookmark data is missing or stale, say exactly what local evidence showed that before suggesting sync or auth.
