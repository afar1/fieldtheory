---
name: library
description: Use when the user asks to find, read, inspect, link, create, append, rename, or update Field Theory Library notes, briefs, scratchpads, wikis, debates, tags, links, or backlinks.
---

# Field Theory Library

Use this skill for local Library markdown.

## Read And Search

Start from the Library tools before relying on memory.

Use `find_library_doc` for title and path search. Use `search_library` or `grep_library` for content search. Use `read_library_doc` for exact content.

Use `get_doc_meta`, `list_doc_links`, `list_doc_backlinks`, `list_tags`, and `list_tagged_docs` when the question is about document structure instead of body text.

## Write

Create or update Library documents only when the user asks for a saved artifact or when the task explicitly requires one.

For updates, read the document first with `read_library_doc`, preserve the user's intent, and pass the returned `version.sha256` as `expectedSha256` to `update_library_doc`.

If the update reports a conflict, read the document again, merge the requested change into the new content, and retry once with the new hash.

Do not use `force` unless the user explicitly asks to overwrite without hash protection.

Use `create_library_doc`, `update_library_doc`, `append_to_doc`, `create_quick_note`, `create_typed_doc`, and `rename_doc` rather than direct filesystem writes.

When writing Field Theory wiki links, do not guess the link target. Use `format_wiki_link` when available, or `ft link <target> --json` as the CLI fallback, then insert the returned `link` string.

Use `save_run_record` for concise durable summaries of useful Codex work. Do not save full transcripts as run records.

## Guardrails

Do not overwrite existing Library documents without an explicit update path and, when possible, an expected hash.

Do not treat Codex session history as a replacement for Field Theory artifacts. Summarize the useful work into durable notes.
