---
name: browser-library
description: Use when the user asks Codex to open a Field Theory Library note, panel, wiki page, scratchpad, brief, or command surface inside the Codex in-app browser.
---

# Field Theory Browser Library

Use this skill for browser-compatible Field Theory Library links inside Codex.

The main point: `fieldtheory://` links are native app deep links, not Codex browser links.

## Workflow

1. Resolve the target document with Field Theory tools, such as `find_library_doc`, `read_library_doc`, or `open_in_field_theory` when needed.
2. Use `get_panel_link` for the Codex browser URL.
3. Return the `markdown` link or the raw `url` from `get_panel_link`.

## URL Contract

The correct source of truth is `~/.fieldtheory/browser-helper.json`.

Use the helper state's `browserUrl`, `host`, `port`, and `token`. The browser URL should load the real Field Theory Browser Library UI and include target params such as:

- `kind=wiki`
- `path=<Library relative markdown path>`
- `contentMode=rendered`

Do not send Codex to `fieldtheory://...` URLs. Codex blocks custom app schemes.

Do not use `file://...` URLs. Codex blocks local file browser navigation.

Do not start a temporary Markdown preview server as the primary answer. A preview shows content, but it is not Field Theory: it loses Library navigation, rendered/editor modes, state sync, and native helper behavior.

Prefer `get_panel_link` over shelling out to `ft codex panel`. Older installed CLI versions may return a panel redirect URL rather than the direct Browser Library URL with `api`, `token`, `kind`, `path`, and `contentMode` params.

Browser Library URLs contain a local helper token. It is okay to return the link to the user in the current Codex session, but do not save tokenized URLs into durable Library documents, run records, public issues, PRs, or external messages.

If the browser helper is missing or not responding, say the app/browser helper is not available and give the next concrete action: start Field Theory with its browser helper enabled, then try the same link request again.
