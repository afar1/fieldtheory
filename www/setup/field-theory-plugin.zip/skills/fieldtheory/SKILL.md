---
name: fieldtheory
description: Use Field Theory local Library notes, portable commands, active document context, bookmarks, and saved run records from Codex. Trigger when the user mentions Field Theory, FT, ft CLI commands, Library notes, current Field Theory document, portable commands, briefs, scratchpads, bookmarks, project memory.
---

# Field Theory

Use Field Theory as the user's local project memory, command layer, reading history, and durable work artifact system.

Field Theory has these main local surfaces:

- `Library`: readable markdown notes, briefs, scratchpads, plans, wiki pages, debates, and saved artifacts.
- `Commands`: portable markdown actions in `~/.fieldtheory/library/Commands`.
- `Bookmarks`: local X/Twitter bookmark data and derived markdown.

## Recognize FT CLI Language

The user may use Field Theory CLI language directly. Treat these as Field Theory concepts:

- `ft current`, current document, active document, current note edits, or "what am I looking at" means active Field Theory document context. Use the `current-document` sibling skill.
- `ft library`, Library, briefs, scratchpads, wiki pages, debates, notes, docs, tags, links, backlinks, tree, find, grep, cat, head, or meta means local Library markdown. Use the `library` sibling skill.
- `ft commands`, Commands, portable commands, command files, `/brief`, `/goal`, `/orchestrate`, or `/refactor` means markdown command documents. Read an explicitly requested command with `read_command`.
- `ft panel`, `@field-theory panel`, "open ft panel", "open this in Codex browser", or "Field Theory Browser Library" means return a Codex-safe browser Library URL using `get_panel_link`. Use the `browser-library` sibling skill.
- `ft bookmarks`, bookmarks, saved tweets, X bookmarks, search/list/show/stats/categories/domains/folders/sample means local bookmark data. Use the `bookmarks` sibling skill.
- `ft note`, `ft append`, `ft new`, and `ft rename` are Library write operations and should be used carefully.

## Skill Routing

Use sibling skills as expert homes:

- `setup`: Mac onboarding, support-call recording readiness, local transcription, account connection, and optional Builder setup.

- `library`: Library search, read, metadata, links, tags, notes, and safe document writes.
- `browser-library`: Codex in-app browser links for the real Field Theory Library UI.
- `current-document`: active document reads, line mapping, and hash-protected edits.
- `bookmarks`: local X/Twitter bookmark search, reading, stats, and sampling.

## Routing Precedence

When more than one Field Theory surface could answer, choose the most local and specific source:

1. Explicit user command or named skill.
2. Active/current document when the user says current, active, visible, selected, line, this note, or what I am looking at.
3. Browser Library panel when the user asks to open or show Field Theory inside Codex.
4. Library documents for notes, briefs, scratchpads, wiki pages, links, tags, and saved artifacts.
5. Command files for explicitly requested portable procedures.
6. Local bookmarks for saved tweets, remembered links, bookmark folders, categories, and domains.
7. Memory or web only after the local Field Theory source is not enough.

## How To Work

Start from real local state. Use the Field Theory MCP tools first. If a needed `ft` surface is not exposed as a tool yet, use the installed `ft` CLI instead of guessing where files live.

For active document context, Library work, browser Library links, and bookmarks, follow the matching sibling skill. This parent skill keeps routing and boundaries; the sibling skill owns the detailed procedure.

Create or update Library documents only when the user asks for a saved artifact or when the current task explicitly requires one. When updating an existing document, preserve the user's intent and use expected-hash protection when available.

When saving a run record, write a useful artifact rather than a full transcript. Include the prompt, repo, branch if known, important files, what changed, verification, and follow-up work.

## Useful CLI Equivalents

```bash
ft paths --json
ft status --json
ft current --json
ft current --summary --json
ft current update --stdin --expected-sha256 <sha>
ft recent --json
ft ls briefs --json
ft tree --json
ft find "<title or path query>" --json
ft grep "<content query>" --json
ft head "<path>" --lines 40 --json
ft meta "<path>" --json
ft links "<path>" --json
ft backlinks "<path>" --json
ft tags --json
ft tagged "<tag>" --json
ft library search "<query>" --json
ft library show "<path>" --json
ft library create "<path>" --stdin --json
ft library update "<path>" --stdin --expected-sha256 <hash> --json
ft append "<path>" --stdin --json
ft note "quick note text" --json
ft new brief "Title" --stdin --json
ft commands list --json
ft commands show "<name>" --json
ft search "<bookmark query>" --json
ft list --category tool --json
ft show <bookmark-id> --json
ft stats --json
ft categories
ft domains
ft folders
ft sample tool --limit 10
```

## Tool Map

Use these MCP tools for common `ft` language:

- `ft paths` -> `get_paths`
- `ft status` -> `get_status`
- `ft current` -> `get_current_document`
- `ft recent` -> `get_recent_files`
- `ft ls` -> `list_places`
- `ft tree` -> `get_library_tree`
- `ft find` -> `find_library_doc`
- `ft grep` -> `grep_library`
- `ft cat` or `ft library show` -> `read_library_doc`
- `ft head` -> `read_doc_head`
- `ft meta` -> `get_doc_meta`
- `ft links` -> `list_doc_links`
- `ft backlinks` -> `list_doc_backlinks`
- `ft tags` -> `list_tags`
- `ft tagged` -> `list_tagged_docs`
- `ft note` -> `create_quick_note`
- `ft append` -> `append_to_doc`
- `ft new` -> `create_typed_doc`
- `ft rename` -> `rename_doc`
- `ft commands list` -> `list_commands`
- `ft commands show` -> `read_command`
- `ft open` -> `open_in_field_theory`
- Browser Library panel requests -> `get_panel_link`
- `ft search` -> `search_bookmarks`
- `ft list` -> `list_bookmarks`
- `ft show` -> `show_bookmark`
- `ft stats` -> `get_bookmark_stats`
- `ft categories` -> `list_bookmark_categories`
- `ft domains` -> `list_bookmark_domains`
- `ft folders` -> `list_bookmark_folders`
- `ft sample` -> `sample_bookmarks`
- `ft ask` -> `ask_knowledge_base`
- `ft lint` -> `lint_knowledge_base`

## Guardrails

Keep Field Theory data local-first.

Do not overwrite existing Library documents without an explicit update path and, when possible, an expected hash.

Do not invent document-editing CLI commands. For the active Field Theory document, the write command is `ft current update --stdin --expected-sha256 <sha>`.

Do not treat Codex session history as a replacement for Field Theory artifacts. Summarize the useful work into durable notes.

Do not recreate the Codex app inside Field Theory. Use Codex as the agent shell and Field Theory as the memory, command, and artifact layer.

Prefer small, concrete tool calls over broad shell commands. If a user says "boil the ocean," expand coverage thoughtfully, but still avoid destructive or long-running `ft` operations unless they ask for that exact action.
