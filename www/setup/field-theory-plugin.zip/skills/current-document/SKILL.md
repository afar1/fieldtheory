---
name: current-document
description: Use when the user asks about the active Field Theory document, current note, visible line numbers, selected text, or wants Codex to edit what Field Theory is currently showing.
---

# Field Theory Current Document

Use this skill for the active Field Theory document attached to the Mac app terminal context.

## Read

Call `get_current_document` first. It may return the Browser Library panel's current document before falling back to `ft current --json`, so treat it as the best current-document source for Codex.

It returns the document content, source path, editability, hash, content mode, and line-number mapping when available.

Use `summary: true` only when metadata is enough.

## Edit

there is one supported path.

Read `ft current --json`, unwrap the v1 envelope, edit the returned `data.content` as normal Markdown, then send the complete edited Markdown to:

```bash
ft current update --stdin --expected-sha256 <data.version.sha256>
```

If you read with the MCP tool `get_current_document` instead, it already unwraps the CLI envelope; use its top-level `content` and `version.sha256`.

After a successful JSON update, use the newly printed `data.version.sha256` as the expected hash for the next edit to the same document.

After an edit, read the document again with `get_current_document` or `ft current --json` and verify the requested change is present.

If the update says the file changed on disk, run `ft current --json` again, merge the user's requested change into the returned `data.content`, then retry once with the new `data.version.sha256`.

Never run `ft current update --stdin` by itself; it must receive the full edited document content on stdin.

For multiline edits, pipe the content on stdin; do not pass Markdown as command arguments.

Do not use `sed -i`, `awk > file`, `cat` against `sourcePath`, the Codex `apply_patch` tool, direct filesystem writes, context-cache files, temp-file rewrites, or invented line-edit commands such as `ft edit --file ... --line ...`.

## Line Numbers

For current-document line-number questions, read `data.lineNumbers` from `ft current --json` or the top-level `lineNumbers` field from `get_current_document` before answering.

If `lineNumbers.activeLineKind` is `renderedVisual`, the user is referring to visible rendered rows. Answer from `lineNumbers.lines[].visibleLine` and use `sourceLine` only as the Markdown source mapping.

Do not answer visible-line questions by splitting `content` on newlines unless `lineNumbers.activeLineKind` is `source` or no line map is available.
