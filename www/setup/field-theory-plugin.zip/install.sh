#!/bin/sh
# Local Codex preview install; never publishes or modifies another plugin.
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
source_dir="$script_dir/0.1.0+codex.20260528062418"
if [ -f "$script_dir/.codex-plugin/plugin.json" ]; then source_dir="$script_dir"; fi
if [ "${1:-}" = --check ]; then exec /bin/sh "$source_dir/scripts/check-setup.sh"; fi
if [ "${1:-}" = --claude ]; then
  printf 'For an isolated Claude Code preview session, run:\nclaude --plugin-dir "%s"\n' "$source_dir"
  exit 0
fi
node_bin=''
for candidate in "${FIELD_THEORY_NODE_BIN:-}" "$(command -v node 2>/dev/null || true)" "$HOME/.local/bin/node" "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" /opt/homebrew/bin/node /usr/local/bin/node; do
  if [ -n "$candidate" ] && [ -x "$candidate" ] && "$candidate" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 18 ? 0 : 1)' >/dev/null 2>&1; then node_bin=$candidate; break; fi
done
if [ -z "$node_bin" ]; then
  printf '%s\n' 'Install Node LTS from https://nodejs.org/en/download, then run this installer again. No Builder tools or ft CLI are required.' >&2
  exit 1
fi
"$node_bin" "$source_dir/scripts/install-codex.js" "$source_dir"
