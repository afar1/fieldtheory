#!/bin/sh
# Read-only preflight: intentionally works without Node, Python, Homebrew or ft.
set -eu
if [ "$(uname -s)" != Darwin ]; then
  printf '%s\n' 'This is not a local Mac environment. Open a supported local desktop session before setting up the user’s Mac.'
  exit 1
fi
if [ -d '/Applications/Field Theory.app' ] || [ -d "$HOME/Applications/Field Theory.app" ]; then
  printf '%s\n' 'Field Theory: installed; runtime/account/recording readiness not yet checked.'
else
  printf '%s\n' 'Field Theory: not found in Applications. Install through Onboard or https://fieldtheory.dev/.'
fi
found=false
for runtime in "${FIELD_THEORY_NODE_BIN:-}" "$(command -v node 2>/dev/null || true)" "$HOME/.local/bin/node" /opt/homebrew/bin/node /usr/local/bin/node; do
  if [ -n "$runtime" ] && [ -x "$runtime" ] && "$runtime" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 18 ? 0 : 1)' >/dev/null 2>&1; then found=true; break; fi
done
if [ "$found" = true ]; then
  printf '%s\n' 'Plugin runtime: available. Connect the plugin and call get_setup_status.'
else
  printf '%s\n' 'Plugin runtime: Node.js 18+ is missing. Install Node LTS from https://nodejs.org/en/download, then restart your assistant. Builder is not required.'
fi
printf '%s\n' 'Computer use: unverified. Test through the assistant’s actual Mac computer-use tools.' 'Call audio and transcript handoff: unverified. A real recording test is required.'
