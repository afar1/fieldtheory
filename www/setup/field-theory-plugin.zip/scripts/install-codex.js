const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const source = path.resolve(process.argv[2]);
const manifest = JSON.parse(fs.readFileSync(path.join(source, '.codex-plugin/plugin.json'), 'utf8'));
if (!/^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.+-]+)?$/.test(manifest.version)) throw new Error('Invalid plugin version');
const root = process.env.CODEX_HOME || path.join(os.homedir(), '.codex');
fs.mkdirSync(root, { recursive: true });
const lock = path.join(root, '.field-theory-plugin-install.lock');
try { fs.mkdirSync(lock); } catch { throw new Error('Another Field Theory plugin installer is running.'); }
try {
  const destination = path.join(root, 'plugins/cache/personal/field-theory', manifest.version);
  const configPath = path.join(root, 'config.toml');
  const config = fs.existsSync(configPath) ? fs.readFileSync(configPath, 'utf8') : '';
  const lines = config.split('\n');
  const header = '[plugins."field-theory@personal"]';
  const sections = lines.flatMap((line, i) => /^\s*\[plugins\.(["'])field-theory@personal\1\]\s*(?:#.*)?$/.test(line) ? [i] : []);
  if (sections.length > 1) throw new Error('Duplicate Field Theory plugin config; resolve it before installing.');
  const start = sections[0] ?? -1;
  if (start < 0 && config.includes('field-theory@personal')) throw new Error('Unrecognized Field Theory config form; enable the plugin in Codex settings instead of overwriting it.');
  if (start < 0) lines.push('', header, 'enabled = true', '');
  else {
    let end = start + 1;
    while (end < lines.length && !/^\s*\[/.test(lines[end])) end++;
    const enabled = lines.findIndex((line, i) => i > start && i < end && /^\s*enabled\s*=/.test(line));
    if (enabled < 0) lines.splice(end, 0, 'enabled = true');
    else lines[enabled] = 'enabled = true';
  }
  const updated = lines.join('\n');
  const staging = fs.mkdtempSync(path.join(root, '.field-theory-plugin-stage-'));
  try {
    fs.cpSync(source, staging, { recursive: true });
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    if (fs.existsSync(destination)) {
      const backups = path.join(root, 'field-theory-plugin-backups');
      fs.mkdirSync(backups, { recursive: true });
      fs.renameSync(destination, path.join(backups, manifest.version + '-' + Date.now()));
    }
    fs.renameSync(staging, destination);
    if (updated !== config) {
      if (fs.existsSync(configPath)) fs.copyFileSync(configPath, configPath + '.field-theory-backup-' + Date.now());
      const temporary = path.join(root, '.field-theory-config-' + process.pid);
      fs.writeFileSync(temporary, updated, { mode: 0o600 });
      fs.renameSync(temporary, configPath);
    }
  } finally { fs.rmSync(staging, { recursive: true, force: true }); }
  console.log(`Installed local preview: ${destination}\nRestart Codex and start a new chat. This is not an official marketplace listing.`);
} finally { fs.rmdirSync(lock); }
