#!/bin/sh
set -eu
plugin_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
for runtime in "${FIELD_THEORY_NODE_BIN:-}" "$(command -v node 2>/dev/null || true)" "$HOME/.local/bin/node" /opt/homebrew/bin/node /usr/local/bin/node; do
  if [ -n "$runtime" ] && [ -x "$runtime" ] && "$runtime" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 18 ? 0 : 1)' >/dev/null 2>&1; then
    exec "$runtime" "$plugin_dir/mcp-server/server.js"
  fi
done
printf '%s\n' 'Field Theory needs Node.js 18 or later on this Mac. Install the current LTS from https://nodejs.org/en/download, then restart your assistant. No ft CLI is required for setup status.' >&2
exit 127
