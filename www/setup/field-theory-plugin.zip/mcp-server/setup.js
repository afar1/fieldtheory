const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const ACTIONS = ['open-onboarding', 'open-account', 'open-permissions', 'open-transcription', 'prepare-parakeet', 'set-recording-source'];
const SOURCES = ['microphone', 'system-audio', 'microphone-and-system-audio'];

function helperState() {
  try {
    const state = JSON.parse(fs.readFileSync(process.env.FT_BROWSER_HELPER_STATE_PATH || path.join(os.homedir(), '.fieldtheory', 'browser-helper.json'), 'utf8'));
    // Never forward the local authentication token to a network host.
    if (!['127.0.0.1', 'localhost', '::1'].includes(state.host) || !Number.isInteger(state.port) || state.port < 1 || state.port > 65535 || typeof state.token !== 'string' || !state.token) return null;
    return state;
  } catch { return null; }
}

function request(route, action, source) {
  const helper = helperState();
  if (!helper) return Promise.reject(new Error('helper-unavailable'));
  return new Promise((resolve, reject) => {
    const body = action ? JSON.stringify({ action, ...(source ? { source } : {}) }) : null;
    const req = http.request({ hostname: helper.host, port: helper.port, path: route, method: body ? 'POST' : 'GET', timeout: 5000,
      headers: { 'X-FieldTheory-Browser-Token': helper.token, 'X-FieldTheory-Browser-Client': 'field-theory-setup', ...(body ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } : {}) },
    }, res => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', chunk => { data += chunk; if (data.length > 128 * 1024) req.destroy(new Error('response-too-large')); });
      res.on('end', () => {
        if (res.statusCode !== 200) return reject(new Error(res.statusCode === 404 ? 'app-update-required' : 'helper-request-failed'));
        try { resolve(JSON.parse(data)); } catch { reject(new Error('invalid-helper-response')); }
      });
      res.on('error', () => reject(new Error('helper-unavailable')));
    });
    req.on('error', () => reject(new Error('helper-unavailable')));
    req.on('timeout', () => req.destroy());
    req.end(body);
  });
}

// Explicit projection: unexpected server fields, errors, user content and credentials
// must never become part of the setup report.
function projectStatus(s) {
  const str = v => typeof v === 'string' ? v.slice(0, 100) : null;
  const bool = v => typeof v === 'boolean' ? v : null;
  return {
    app: { version: str(s.app?.version) },
    account: { signedIn: bool(s.account?.signedIn) },
    permissions: { microphone: str(s.permissions?.microphone), screen: str(s.permissions?.screen), accessibility: bool(s.permissions?.accessibility) },
    recording: { source: str(s.recording?.source), hotkey: str(s.recording?.hotkey), engine: str(s.recording?.engine) },
    parakeet: { runtimeInstalled: bool(s.parakeet?.runtimeInstalled), serverState: str(s.parakeet?.serverState), activeEngine: str(s.parakeet?.activeEngine), engines: Array.isArray(s.parakeet?.engines) ? s.parakeet.engines.slice(0, 10).map(e => ({ engine: str(e.engine), verified: bool(e.verified), needsReinstall: bool(e.needsReinstall), hasError: Boolean(e.lastError || e.setupError) })) : [] },
    setup: { parakeetPreparing: bool(s.setup?.parakeetPreparing), hasError: Boolean(s.setup?.lastError) },
  };
}

async function getStatus() {
  const appInstalled = ['/Applications/Field Theory.app', path.join(os.homedir(), 'Applications', 'Field Theory.app')].some(p => fs.existsSync(p));
  const report = { schemaVersion: 1, platform: process.platform, appInstalled, helper: 'unknown', readiness: null,
    verification: { computerUse: 'host-must-verify', callAudio: 'user-test-required', transcriptHandoff: 'user-test-required' },
    nextStep: 'Open Field Theory, then check again. If missing, install it from https://fieldtheory.dev/.',
  };
  if (process.platform !== 'darwin') { report.nextStep = 'This process is not running on macOS. Use a supported local Mac session; do not treat a cloud VM as the user’s computer.'; return report; }
  try {
    const result = await request('/native/onboarding/status');
    if (!result.ok || result.status?.schemaVersion !== 1) throw new Error('app-update-required');
    report.helper = 'connected';
    report.appInstalled = true;
    report.readiness = projectStatus(result.status);
    report.nextStep = 'Address only missing essentials. Verify computer use with host tools and a user-triggered call recording before declaring ready. Offer Builder afterward.';
  } catch (error) {
    report.helper = error.message === 'app-update-required' ? 'app-update-required' : 'unavailable';
    if (report.helper === 'app-update-required') report.nextStep = 'The running app does not support setup status. Use the supplied Field Theory preview app after explaining the update. Existing setup is unknown, not missing.';
  }
  return report;
}

async function runAction(action, source) {
  if (!ACTIONS.includes(action)) throw new Error('Unsupported setup action.');
  if (action === 'set-recording-source' && !SOURCES.includes(source)) throw new Error('Choose a supported recording source.');
  if (source !== undefined && action !== 'set-recording-source') throw new Error('Source is only supported for set-recording-source.');
  if (process.platform !== 'darwin') throw new Error('Setup actions require the local Mac host.');
  const result = await request('/native/onboarding/action', action, source);
  if (!result.ok || !result.result?.accepted) throw new Error('Field Theory did not accept the action. Open the app and continue setup there.');
  return { accepted: true, action, nextStep: 'Recheck get_setup_status. Account verification and Mac permissions happen in the app or browser, never in this chat.' };
}
module.exports = { ACTIONS, SOURCES, getStatus, runAction };
