#!/usr/bin/env node

const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const FT_BIN = process.env.FIELD_THEORY_FT_BIN || 'ft';
const MAX_OUTPUT_BYTES = 2 * 1024 * 1024;
const PLUGIN_MANIFEST = readPluginManifest();
const PLUGIN_VERSION = PLUGIN_MANIFEST.version || '0.0.0';

const NO_PROPS = { type: 'object', properties: {}, additionalProperties: false };

const setup = require('./setup');
const tools = [
  tool('get_setup_status', 'Check this Mac for Field Theory and report authenticated app readiness without requiring ft. Installed is not verified usable. Never includes notes, email, or tokens.', NO_PROPS),
  tool('setup_action', 'Open a specific Field Theory setup screen or start local Parakeet preparation. Changing recording source requires the user’s choice. Never handles account secrets. Recheck get_setup_status afterward.', {
    type: 'object', properties: { action: { type: 'string', enum: setup.ACTIONS }, source: { type: 'string', enum: setup.SOURCES, description: 'Only for set-recording-source, after the user chooses what to record.' } }, required: ['action'], additionalProperties: false,
  }),
  tool('get_paths', 'Return Field Theory data, Library, commands, and compatibility paths.', NO_PROPS),
  tool('get_status', 'Return Field Theory bookmark sync status and data location.', NO_PROPS),
  tool('get_current_document', 'Return the active Field Theory document attached to the Mac app terminal context.', {
    type: 'object',
    properties: {
      includeContent: { type: 'boolean', description: 'Deprecated. Content is included by default unless this is false.' },
      summary: { type: 'boolean', description: 'Omit active document content.' },
    },
    additionalProperties: false,
  }),
  tool('get_recent_files', 'Return recent repo files an agent can use for “that file” references.', {
    type: 'object',
    properties: {
      repo: { type: 'string' },
      limit: { type: 'number', minimum: 1, maximum: 100 },
    },
    additionalProperties: false,
  }),
  tool('list_places', 'List Field Theory places or files inside one place.', {
    type: 'object',
    properties: {
      place: { type: 'string', description: 'library, commands, briefs, scratchpad, wikis, debates, recent, or current.' },
      limit: { type: 'number', minimum: 1, maximum: 500 },
    },
    additionalProperties: false,
  }),
  tool('get_library_tree', 'Return a compact Field Theory Library tree.', {
    type: 'object',
    properties: { limit: { type: 'number', minimum: 1, maximum: 500 } },
    additionalProperties: false,
  }),
  tool('find_library_doc', 'Search Field Theory document titles and paths.', querySchema()),
  tool('search_library', 'Search Field Theory Library markdown documents.', querySchema()),
  tool('grep_library', 'Search inside Field Theory markdown content.', querySchema()),
  tool('read_library_doc', 'Read one Field Theory Library markdown document.', pathSchema()),
  tool('read_doc_head', 'Read the first lines of a Field Theory Library or command document.', {
    type: 'object',
    properties: {
      path: { type: 'string' },
      lines: { type: 'number', minimum: 1, maximum: 400 },
    },
    required: ['path'],
    additionalProperties: false,
  }),
  tool('get_doc_meta', 'Return metadata for a Field Theory Library or command document.', pathSchema()),
  tool('list_doc_links', 'List wiki-style links from a Field Theory document.', pathSchema()),
  tool('format_wiki_link', 'Return the canonical Field Theory wiki link for a Library document or command.', {
    type: 'object',
    properties: {
      target: { type: 'string', description: 'Document title, path, command name, or filename.' },
      alias: { type: 'string', description: 'Optional display text for the wikilink.' },
    },
    required: ['target'],
    additionalProperties: false,
  }),
  tool('list_doc_backlinks', 'List documents that link to a Field Theory document.', pathSchema()),
  tool('list_tags', 'List tags found in Field Theory markdown.', NO_PROPS),
  tool('list_tagged_docs', 'List Field Theory documents with a tag.', {
    type: 'object',
    properties: { tag: { type: 'string' } },
    required: ['tag'],
    additionalProperties: false,
  }),
  tool('create_library_doc', 'Create a Field Theory Library markdown document from provided content.', {
    type: 'object',
    properties: { path: { type: 'string' }, content: { type: 'string' } },
    required: ['path', 'content'],
    additionalProperties: false,
  }),
  tool('update_library_doc', 'Replace a Field Theory Library markdown document using expected hash protection unless force is explicit.', {
    type: 'object',
    properties: {
      path: { type: 'string' },
      content: { type: 'string' },
      expectedSha256: { type: 'string', description: 'Current document sha256 guard.' },
      force: { type: 'boolean', description: 'Overwrite without expectedSha256.' },
    },
    required: ['path', 'content'],
    additionalProperties: false,
  }),
  tool('append_to_doc', 'Append text to a Field Theory document.', {
    type: 'object',
    properties: { path: { type: 'string' }, content: { type: 'string' } },
    required: ['path', 'content'],
    additionalProperties: false,
  }),
  tool('create_quick_note', 'Append a quick note to today’s Scratchpad file.', {
    type: 'object',
    properties: {
      text: { type: 'string' },
      title: { type: 'string', description: 'Title to use when creating today’s Scratchpad file.' },
    },
    required: ['text'],
    additionalProperties: false,
  }),
  tool('create_typed_doc', 'Create a Field Theory document in the correct place by type.', {
    type: 'object',
    properties: {
      type: { type: 'string', enum: ['brief', 'command', 'scratchpad', 'wiki', 'debate'] },
      title: { type: 'string' },
      content: { type: 'string' },
    },
    required: ['type', 'title'],
    additionalProperties: false,
  }),
  tool('rename_doc', 'Rename a Field Theory document using Field Theory places.', {
    type: 'object',
    properties: { path: { type: 'string' }, title: { type: 'string' } },
    required: ['path', 'title'],
    additionalProperties: false,
  }),
  tool('list_commands', 'List Field Theory portable command markdown files.', NO_PROPS),
  tool('read_command', 'Read one Field Theory portable command markdown file.', {
    type: 'object',
    properties: { name: { type: 'string', description: 'Command name or markdown path.' } },
    required: ['name'],
    additionalProperties: false,
  }),
  tool('open_in_field_theory', 'Open or prepare a Field Theory app target for a Library document.', {
    type: 'object',
    properties: {
      path: { type: 'string', description: 'Markdown path, title, or filename.' },
      query: { type: 'string', description: 'Find one matching document and open it.' },
      launch: { type: 'boolean', description: 'Launch the app. Defaults to false for safety.' },
    },
    additionalProperties: false,
  }),
  tool('get_panel_link', 'Return a Codex-safe Field Theory Browser Library URL for the Library or one matching Library document.', {
    type: 'object',
    properties: {
      path: { type: 'string', description: 'Markdown path, title, filename, or "library". Defaults to the Library panel.' },
      query: { type: 'string', description: 'Find one matching document and link it.' },
      label: { type: 'string', description: 'Markdown link label. Defaults to "Open in Field Theory panel".' },
    },
    additionalProperties: false,
  }),
  tool('search_bookmarks', 'Full-text search across local bookmarks.', bookmarkSearchSchema()),
  tool('list_bookmarks', 'List local bookmarks with filters.', bookmarkListSchema()),
  tool('show_bookmark', 'Show one bookmark in detail.', {
    type: 'object',
    properties: { id: { type: 'string' } },
    required: ['id'],
    additionalProperties: false,
  }),
  tool('get_bookmark_stats', 'Return aggregate bookmark statistics.', NO_PROPS),
  tool('list_bookmark_categories', 'Show bookmark category distribution.', NO_PROPS),
  tool('list_bookmark_domains', 'Show bookmark domain distribution.', NO_PROPS),
  tool('list_bookmark_folders', 'Show X bookmark folder distribution from local counts.', NO_PROPS),
  tool('sample_bookmarks', 'Sample bookmarks by category.', {
    type: 'object',
    properties: {
      category: { type: 'string', description: 'Category: tool, security, technique, launch, research, opinion, commerce.' },
      limit: { type: 'number', minimum: 1, maximum: 100 },
    },
    required: ['category'],
    additionalProperties: false,
  }),
  tool('ask_knowledge_base', 'Ask a question against the markdown knowledge base.', {
    type: 'object',
    properties: {
      question: { type: 'string' },
      save: { type: 'boolean', description: 'Save the answer as a concept page.' },
    },
    required: ['question'],
    additionalProperties: false,
  }),
  tool('lint_knowledge_base', 'Health-check the markdown knowledge base.', {
    type: 'object',
    properties: { fix: { type: 'boolean', description: 'Auto-fix fixable issues.' } },
    additionalProperties: false,
  }),
  tool('list_seeds', 'List saved Field Theory idea seeds.', NO_PROPS),
  tool('show_seed', 'Show one saved Field Theory idea seed.', idSchema('seedId')),
  tool('list_repos', 'List saved default repo paths for ideas runs.', NO_PROPS),
  tool('list_frames', 'List available 2x2 frames.', NO_PROPS),
  tool('show_frame', 'Show one 2x2 frame in detail.', idSchema('id')),
  tool('list_possible_runs', 'List recent possibility runs.', NO_PROPS),
  tool('show_possible_run', 'Show one possibility run in detail.', { type: 'object', properties: { runId: { type: 'string' } }, additionalProperties: false }),
  tool('render_possible_grid', 'Render the 2x2 grid for a possibility run or batch.', { type: 'object', properties: { target: { type: 'string', description: 'Run id, batch id, latest, or latest-batch.' } }, additionalProperties: false }),
  tool('list_possible_dots', 'Render all scored ideas for a possibility run or batch.', { type: 'object', properties: { target: { type: 'string', description: 'Run id, batch id, latest, or latest-batch.' } }, additionalProperties: false }),
  tool('get_possible_prompt', 'Print the exportable prompt for a scored idea.', idSchema('dotId')),
  tool('save_run_record', 'Create a concise Field Theory Library run record for useful Codex work.', {
    type: 'object',
    properties: {
      title: { type: 'string' },
      prompt: { type: 'string' },
      summary: { type: 'string' },
      repoPath: { type: 'string' },
      branch: { type: 'string' },
      files: { type: 'array', items: { type: 'string' } },
      verification: { type: 'array', items: { type: 'string' } },
      followUps: { type: 'array', items: { type: 'string' } },
    },
    required: ['title', 'summary'],
    additionalProperties: false,
  }),
];

let inputBuffer = '';

process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  inputBuffer += chunk;
  drainMessages();
});

function drainMessages() {
  let newlineIndex;
  while ((newlineIndex = inputBuffer.indexOf('\n')) !== -1) {
    const raw = inputBuffer.slice(0, newlineIndex).trim();
    inputBuffer = inputBuffer.slice(newlineIndex + 1);
    if (raw === '') continue;
    void handleRawMessage(raw);
  }
}

async function handleRawMessage(raw) {
  let message;
  try {
    message = JSON.parse(raw);
  } catch (error) {
    sendError(null, -32700, `Parse error: ${error.message}`);
    return;
  }

  if (!Object.prototype.hasOwnProperty.call(message, 'id')) return;

  try {
    if (message.method === 'initialize') {
      sendResult(message.id, {
        protocolVersion: message.params?.protocolVersion || '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: PLUGIN_MANIFEST.name || 'field-theory', version: PLUGIN_VERSION },
      });
      return;
    }

    if (message.method === 'tools/list') {
      sendResult(message.id, { tools });
      return;
    }

    if (message.method === 'tools/call') {
      const result = await callTool(message.params?.name, message.params?.arguments || {});
      sendResult(message.id, result);
      return;
    }

    sendError(message.id, -32601, `Unknown method: ${message.method}`);
  } catch (error) {
    sendResult(message.id, toolError(error.message || String(error)));
  }
}

function readPluginManifest() {
  const manifestPath = path.resolve(__dirname, '..', '.codex-plugin', 'plugin.json');
  return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
}

async function callTool(name, args) {
  switch (name) {
    case 'get_setup_status':
      return jsonTool(await setup.getStatus());
    case 'setup_action':
      return jsonTool(await setup.runAction(args.action, args.source));
    case 'get_paths':
      return jsonTool(await ftJson(['paths', '--json']));
    case 'get_status':
      return jsonTool(await ftJson(['status', '--json']));
    case 'get_current_document':
      return jsonTool(await getCurrentDocument(args));
    case 'get_recent_files':
      return jsonTool(await ftJson(['recent', args.repo ? '--repo' : null, args.repo || null, '--limit', String(args.limit || 10), '--json']));
    case 'list_places':
      return jsonTool(await ftJson(['ls', args.place || null, args.limit ? '--limit' : null, args.limit ? String(args.limit) : null, '--json']));
    case 'get_library_tree':
      return jsonTool(await ftJson(['tree', '--limit', String(args.limit || 80), '--json']));
    case 'find_library_doc':
      return jsonTool(await ftJson(['find', requireString(args.query, 'query'), '--limit', String(args.limit || 20), '--json']));
    case 'search_library':
      return jsonTool(await ftJson(['library', 'search', requireString(args.query, 'query'), '--limit', String(args.limit || 20), '--json']));
    case 'grep_library':
      return jsonTool(await ftJson(['grep', requireString(args.query, 'query'), '--limit', String(args.limit || 20), '--json']));
    case 'read_library_doc':
      return jsonTool(await ftJson(['library', 'show', requireString(args.path, 'path'), '--json']));
    case 'read_doc_head':
      return jsonTool(await ftJson(['head', requireString(args.path, 'path'), '--lines', String(args.lines || 40), '--json']));
    case 'get_doc_meta':
      return jsonTool(await ftJson(['meta', requireString(args.path, 'path'), '--json']));
    case 'list_doc_links':
      return jsonTool(await ftJson(['links', requireString(args.path, 'path'), '--json']));
    case 'format_wiki_link':
      return jsonTool(await ftJson(['link', requireString(args.target, 'target'), args.alias ? '--alias' : null, args.alias || null, '--json']));
    case 'list_doc_backlinks':
      return jsonTool(await ftJson(['backlinks', requireString(args.path, 'path'), '--json']));
    case 'list_tags':
      return jsonTool(await ftJson(['tags', '--json']));
    case 'list_tagged_docs':
      return jsonTool(await ftJson(['tagged', requireString(args.tag, 'tag'), '--json']));
    case 'create_library_doc':
      return jsonTool(await ftJson(['library', 'create', requireString(args.path, 'path'), '--stdin', '--json'], requireString(args.content, 'content')));
    case 'update_library_doc':
      if (!args.expectedSha256 && args.force !== true) throw new Error('update_library_doc requires expectedSha256 unless force is explicitly true.');
      return jsonTool(await ftJson([
        'library', 'update', requireString(args.path, 'path'), '--stdin',
        args.expectedSha256 ? '--expected-sha256' : null, args.expectedSha256 || null,
        args.force ? '--force' : null, '--json',
      ], requireString(args.content, 'content')));
    case 'append_to_doc':
      return jsonTool(await ftJson(['append', requireString(args.path, 'path'), '--stdin', '--json'], requireString(args.content, 'content')));
    case 'create_quick_note':
      return jsonTool(await ftJson(['note', requireString(args.text, 'text'), args.title ? '--title' : null, args.title || null, '--json']));
    case 'create_typed_doc':
      return jsonTool(await ftJson(['new', requireString(args.type, 'type'), requireString(args.title, 'title'), args.content ? '--stdin' : null, '--json'], args.content || undefined));
    case 'rename_doc':
      return jsonTool(await ftJson(['rename', requireString(args.path, 'path'), requireString(args.title, 'title'), '--json']));
    case 'list_commands':
      return jsonTool(await ftJson(['commands', 'list', '--json']));
    case 'read_command':
      return jsonTool(await ftJson(['commands', 'show', requireString(args.name, 'name'), '--json']));
    case 'open_in_field_theory':
      return jsonTool(await ftJson(['open', args.query ? '--query' : null, args.query || requireString(args.path, 'path'), args.launch === true ? null : '--no-launch', '--json']));
    case 'get_panel_link':
      return jsonTool(await getPanelLink(args));
    case 'search_bookmarks':
      return jsonTool(await ftJson(bookmarkSearchArgs(args)));
    case 'list_bookmarks':
      return jsonTool(await ftJson(bookmarkListArgs(args)));
    case 'show_bookmark':
      return jsonTool(await ftJson(['show', requireString(args.id, 'id'), '--json']));
    case 'get_bookmark_stats':
      return jsonTool(await ftJson(['stats', '--json']));
    case 'list_bookmark_categories':
      return textTool(await ftText(['categories']));
    case 'list_bookmark_domains':
      return textTool(await ftText(['domains']));
    case 'list_bookmark_folders':
      return textTool(await ftText(['folders']));
    case 'sample_bookmarks':
      return textTool(await ftText(['sample', requireString(args.category, 'category'), '--limit', String(args.limit || 10)]));
    case 'ask_knowledge_base':
      return jsonTool(await ftJson(['ask', requireString(args.question, 'question'), args.save ? '--save' : null, '--json']));
    case 'lint_knowledge_base':
      return jsonTool(await ftJson(['lint', args.fix ? '--fix' : null, '--json']));
    case 'list_seeds':
      return textTool(await ftText(['seeds', 'list']));
    case 'show_seed':
      return textTool(await ftText(['seeds', 'show', requireString(args.seedId, 'seedId')]));
    case 'list_repos':
      return textTool(await ftText(['repos', 'list']));
    case 'list_frames':
      return textTool(await ftText(['frames', 'list']));
    case 'show_frame':
      return textTool(await ftText(['frames', 'show', requireString(args.id, 'id')]));
    case 'list_possible_runs':
      return textTool(await ftText(['possible', 'list']));
    case 'show_possible_run':
      return textTool(await ftText(['possible', 'show', args.runId || null]));
    case 'render_possible_grid':
      return textTool(await ftText(['possible', 'grid', args.target || 'latest']));
    case 'list_possible_dots':
      return textTool(await ftText(['possible', 'dots', args.target || 'latest']));
    case 'get_possible_prompt':
      return textTool(await ftText(['possible', 'prompt', requireString(args.dotId, 'dotId')]));
    case 'save_run_record':
      return jsonTool(await saveRunRecord(args));
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

async function saveRunRecord(args) {
  const title = requireString(args.title, 'title');
  const content = formatRunRecord(args);
  const timestamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..+$/, '').replace('T', ' ');
  const relPath = `Codex Context/run-records/${timestamp} - ${slugTitle(title)}.md`;
  return ftJson(['library', 'create', relPath, '--stdin', '--json'], content);
}

async function getPanelLink(args) {
  const panel = await buildBrowserLibraryPanel(args);
  const label = typeof args.label === 'string' && args.label.trim() ? args.label.trim() : 'Open in Field Theory panel';
  return {
    ...panel,
    markdown: `[${label}](${panel.url})`,
  };
}

async function buildBrowserLibraryPanel(args) {
  const helper = readBrowserHelperState();
  if (!helper) {
    throw new Error('Field Theory browser helper is not available. Start Field Theory with its browser helper enabled, then try again.');
  }
  await assertBrowserHelperAvailable(helper);

  const target = await resolveBrowserLibraryTarget(args);
  return {
    path: target.path || null,
    relPath: target.relPath || null,
    target: target.params,
    url: buildBrowserLibraryUrl(helper, target.params),
    launched: false,
  };
}

async function resolveBrowserLibraryTarget(args) {
  const input = typeof args.query === 'string' && args.query.trim() ? args.query : args.path;
  const normalizedInput = typeof input === 'string' ? input.trim() : '';
  if (!normalizedInput || normalizedInput.toLowerCase() === 'library') {
    return {
      path: null,
      relPath: null,
      params: { kind: 'library' },
    };
  }

  const opened = await ftJson(['open', args.query ? '--query' : null, normalizedInput, '--no-launch', '--json']);
  if (!opened || typeof opened.path !== 'string' || opened.path.trim() === '') {
    throw new Error('ft open --no-launch --json did not return a Library path.');
  }

  const relPath = relativeLibraryPath(opened.path);
  return {
    path: opened.path,
    relPath,
    params: {
      kind: 'wiki',
      path: relPath,
      contentMode: 'rendered',
    },
  };
}

function relativeLibraryPath(filePath) {
  const relPath = path.relative(libraryRoot(), filePath).split(path.sep).join('/');
  if (relPath.startsWith('..') || path.isAbsolute(relPath) || relPath === '') {
    throw new Error(`Field Theory target is not inside the local Library: ${filePath}`);
  }
  return relPath;
}

function libraryRoot() {
  return path.resolve(process.env.FT_LIBRARY_DIR || path.join(os.homedir(), '.fieldtheory', 'library'));
}

function buildBrowserLibraryUrl(helper, params) {
  const baseUrl = helper.browserUrl || `http://${helper.host}:${helper.port}/`;
  const url = new URL(baseUrl);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new Error(`Field Theory browser helper returned an unsupported browser URL scheme: ${url.protocol}`);
  }
  url.searchParams.set('api', `http://${helper.host}:${helper.port}`);
  url.searchParams.set('token', helper.token);
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, String(value));
  }
  return url.toString();
}

function assertBrowserHelperAvailable(helper) {
  return new Promise((resolve, reject) => {
    const request = http.request({
      host: helper.host,
      port: helper.port,
      path: `/health?token=${encodeURIComponent(helper.token)}`,
      method: 'GET',
      timeout: 1000,
    }, (response) => {
      response.resume();
      response.on('end', () => {
        if (response.statusCode && response.statusCode >= 200 && response.statusCode < 300) {
          resolve();
          return;
        }
        reject(new Error(`Field Theory browser helper returned HTTP ${response.statusCode}.`));
      });
    });
    request.on('timeout', () => {
      request.destroy(new Error('Field Theory browser helper health check timed out.'));
    });
    request.on('error', (error) => {
      reject(new Error('Field Theory browser helper is not responding. Restart Field Theory with its browser helper enabled, then try again.', { cause: error }));
    });
    request.end();
  });
}

async function getCurrentDocument(args) {
  const includeContent = args.summary === true ? false : args.includeContent !== false;
  const panelCurrent = await getBrowserPanelCurrentDocument(includeContent);
  if (panelCurrent) return panelCurrent;
  return ftJson(['current', includeContent ? null : '--summary', '--json']);
}

async function getBrowserPanelCurrentDocument(includeContent) {
  const helper = readBrowserHelperState();
  if (!helper) return null;
  const context = await fetchBrowserHelperCurrent(helper).catch(() => null);
  if (!isActiveLibraryFileContext(context)) return null;
  const filePath = context.filePath;
  const content = fs.readFileSync(filePath, 'utf8');
  const stats = fs.statSync(filePath);
  const version = {
    mtimeMs: stats.mtimeMs,
    size: stats.size,
    sha256: sha256(content),
  };
  const document = {
    title: context.title || path.basename(filePath),
    kind: inferCurrentDocumentKind(context),
    contentMode: 'rendered',
    lineNumbers: {
      activeSurface: 'rendered',
      activeLineKind: null,
      visibleRowsOnly: false,
      instructions: 'The user is viewing rendered content, but no line map was attached. Treat content newline numbers as Markdown source lines, and say when a visible line cannot be resolved.',
      lines: [],
    },
    sourcePath: filePath,
    editable: isMarkdownPath(filePath),
    version: isMarkdownPath(filePath) ? version : null,
    updateCommand: 'ft current update --stdin --expected-sha256 <sha>',
    updatedAt: new Date().toISOString(),
    selection: currentSelection(context),
    recent: [],
    includedPages: [],
  };
  if (includeContent) document.content = content;
  return document;
}

function sha256(value) {
  return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

function isMarkdownPath(filePath) {
  return /\.(md|markdown)$/i.test(path.basename(filePath));
}

function readBrowserHelperState() {
  const filePath = process.env.FT_BROWSER_HELPER_STATE_PATH
    || path.join(os.homedir(), '.fieldtheory', 'browser-helper.json');
  let parsed;
  try {
    parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
  if (typeof parsed.host !== 'string' || typeof parsed.port !== 'number' || typeof parsed.token !== 'string') return null;
  if (!Number.isInteger(parsed.port) || parsed.port <= 0 || parsed.port > 65535) return null;
  return parsed;
}

function fetchBrowserHelperCurrent(helper) {
  return new Promise((resolve, reject) => {
    const request = http.request({
      host: helper.host,
      port: helper.port,
      path: '/native/current',
      method: 'GET',
      headers: {
        'X-FieldTheory-Browser-Token': helper.token,
        'X-FieldTheory-Browser-Client': 'codex-mcp-current',
      },
      timeout: 750,
    }, (response) => {
      let body = '';
      response.setEncoding('utf8');
      response.on('data', (chunk) => {
        body = appendBounded(body, chunk);
      });
      response.on('end', () => {
        if (response.statusCode !== 200) {
          resolve(null);
          return;
        }
        try {
          const parsed = JSON.parse(body);
          resolve(parsed?.context ?? null);
        } catch (error) {
          reject(error);
        }
      });
    });
    request.on('timeout', () => {
      request.destroy(new Error('Browser helper current request timed out.'));
    });
    request.on('error', reject);
    request.end();
  });
}

function isActiveLibraryFileContext(context) {
  return Boolean(
    context
    && typeof context === 'object'
    && !Array.isArray(context)
    && (context.type === 'wiki' || context.type === 'external')
    && typeof context.filePath === 'string'
    && context.filePath
    && typeof context.title === 'string'
    && context.title
    && fs.existsSync(context.filePath)
  );
}

function inferCurrentDocumentKind(context) {
  if (context.type === 'wiki') return 'wiki';
  const relPath = typeof context.relPath === 'string' ? context.relPath : '';
  const filePath = typeof context.filePath === 'string' ? context.filePath : '';
  const lower = `${relPath}\n${filePath}`.toLowerCase();
  if (lower.includes('/librarian/artifacts/') || lower.includes('artifacts/')) return 'artifact';
  if (lower.includes('/briefs/') || lower.startsWith('briefs/')) return 'brief';
  if (lower.includes('/scratchpad/') || lower.startsWith('scratchpad/')) return 'scratchpad';
  if (lower.includes('/debates/') || lower.startsWith('debates/')) return 'debate';
  if (lower.includes('/commands/') || lower.startsWith('commands/')) return 'command';
  return 'document';
}

function currentSelection(context) {
  if (
    typeof context.selectionText !== 'string'
    || typeof context.selectionStart !== 'number'
    || typeof context.selectionEnd !== 'number'
  ) {
    return null;
  }
  return {
    textPath: null,
    preview: context.selectionText.slice(0, 400),
    start: context.selectionStart,
    end: context.selectionEnd,
  };
}

function formatRunRecord(args) {
  const lines = [
    `**${requireString(args.title, 'title')}**`,
    '',
    `*Date written: ${new Date().toISOString().slice(0, 10)}*`,
    '',
    '**Prompt**',
    '',
    args.prompt || '(not provided)',
    '',
    '**Summary**',
    '',
    requireString(args.summary, 'summary'),
  ];

  const repoDetails = [args.repoPath ? `repo: ${args.repoPath}` : null, args.branch ? `branch: ${args.branch}` : null].filter(Boolean);
  if (repoDetails.length) lines.push('', '**Repo**', '', ...repoDetails);
  appendList(lines, 'Files', args.files);
  appendList(lines, 'Verification', args.verification);
  appendList(lines, 'Follow Ups', args.followUps);
  lines.push('');
  return lines.join('\n');
}

function bookmarkSearchArgs(args) {
  return [
    'search', requireString(args.query, 'query'),
    args.author ? '--author' : null, args.author || null,
    args.after ? '--after' : null, args.after || null,
    args.before ? '--before' : null, args.before || null,
    '--limit', String(args.limit || 20),
    '--json',
  ];
}

function bookmarkListArgs(args) {
  return [
    'list',
    args.query ? '--query' : null, args.query || null,
    args.author ? '--author' : null, args.author || null,
    args.after ? '--after' : null, args.after || null,
    args.before ? '--before' : null, args.before || null,
    args.category ? '--category' : null, args.category || null,
    args.domain ? '--domain' : null, args.domain || null,
    args.folder ? '--folder' : null, args.folder || null,
    '--limit', String(args.limit || 30),
    '--offset', String(args.offset || 0),
    '--json',
  ];
}

function ftJson(args, stdin) {
  return runFt(args, stdin).then((stdout) => unwrapCliJsonContract(parseJsonOutput(stdout)));
}

function ftText(args, stdin) {
  return runFt(args, stdin).then((stdout) => stripAnsi(stdout).trim());
}

function runFt(args, stdin) {
  return new Promise((resolve, reject) => {
    const cleanArgs = args.filter((arg) => arg !== null && arg !== undefined);
    const child = spawn(FT_BIN, cleanArgs, {
      env: { ...process.env, PATH: commonPath() },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (chunk) => {
      stdout = appendBounded(stdout, chunk);
    });
    child.stderr.on('data', (chunk) => {
      stderr = appendBounded(stderr, chunk);
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(cliJsonErrorMessage(stdout) || stderr.trim() || stdout.trim() || `${FT_BIN} exited with code ${code}`));
        return;
      }
      resolve(stdout);
    });

    if (stdin !== undefined) child.stdin.end(stdin);
    else child.stdin.end();
  });
}

function appendList(lines, title, values) {
  if (!Array.isArray(values) || values.length === 0) return;
  lines.push('', `**${title}**`, '', ...values.map((value) => `- ${String(value)}`));
}

function slugTitle(title) {
  return title.trim().replace(/[/:]/g, ' ').replace(/\s+/g, ' ').slice(0, 80);
}

function requireString(value, name) {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`Missing required string: ${name}`);
  return value;
}

function appendBounded(current, chunk) {
  const next = current + chunk.toString('utf8');
  if (Buffer.byteLength(next) <= MAX_OUTPUT_BYTES) return next;
  return next.slice(0, MAX_OUTPUT_BYTES) + '\n[output truncated]';
}

function parseJsonOutput(stdout) {
  const text = stripAnsi(stdout).trim();
  const start = firstJsonOffset(text);
  if (start < 0) throw new Error(`Expected JSON from ${FT_BIN}, got: ${text.slice(0, 400)}`);
  return JSON.parse(text.slice(start));
}

function unwrapCliJsonContract(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return value;
  if (value.schemaVersion !== 1 || typeof value.ok !== 'boolean') return value;
  if (value.ok === true && Object.prototype.hasOwnProperty.call(value, 'data')) return value.data;
  if (value.ok === false) throw new Error(cliJsonErrorText(value));
  return value;
}

function cliJsonErrorMessage(stdout) {
  try {
    const value = parseJsonOutput(stdout);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    if (value.schemaVersion !== 1 || value.ok !== false) return null;
    return cliJsonErrorText(value);
  } catch {
    return null;
  }
}

function cliJsonErrorText(value) {
  const message = value.error && typeof value.error.message === 'string' ? value.error.message : 'Field Theory CLI returned an error.';
  const code = value.error && typeof value.error.code === 'string' ? value.error.code : null;
  return code ? `${code}: ${message}` : message;
}

function firstJsonOffset(text) {
  const objectAt = text.indexOf('{');
  const arrayAt = text.indexOf('[');
  if (objectAt < 0) return arrayAt;
  if (arrayAt < 0) return objectAt;
  return Math.min(objectAt, arrayAt);
}

function stripAnsi(value) {
  return value.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '');
}

function commonPath() {
  const prefixes = ['/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin', '/usr/sbin', '/sbin'];
  const existing = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  return [...prefixes, ...existing.filter((item) => !prefixes.includes(item))].join(path.delimiter);
}

function jsonTool(value) {
  return { content: [{ type: 'text', text: JSON.stringify(value, null, 2) }] };
}

function textTool(value) {
  return { content: [{ type: 'text', text: value }] };
}

function toolError(message) {
  return { isError: true, content: [{ type: 'text', text: message }] };
}

function sendResult(id, result) {
  send({ jsonrpc: '2.0', id, result });
}

function sendError(id, code, message) {
  send({ jsonrpc: '2.0', id, error: { code, message } });
}

function send(payload) {
  process.stdout.write(`${JSON.stringify(payload)}\n`);
}

function tool(name, description, inputSchema) {
  return { name, description, inputSchema };
}

function querySchema() {
  return {
    type: 'object',
    properties: {
      query: { type: 'string' },
      limit: { type: 'number', minimum: 1, maximum: 100 },
    },
    required: ['query'],
    additionalProperties: false,
  };
}

function pathSchema() {
  return {
    type: 'object',
    properties: { path: { type: 'string', description: 'Relative or absolute markdown path.' } },
    required: ['path'],
    additionalProperties: false,
  };
}

function idSchema(name) {
  return {
    type: 'object',
    properties: { [name]: { type: 'string' } },
    required: [name],
    additionalProperties: false,
  };
}

function bookmarkSearchSchema() {
  return {
    type: 'object',
    properties: {
      query: { type: 'string' },
      author: { type: 'string' },
      after: { type: 'string', description: 'YYYY-MM-DD' },
      before: { type: 'string', description: 'YYYY-MM-DD' },
      limit: { type: 'number', minimum: 1, maximum: 100 },
    },
    required: ['query'],
    additionalProperties: false,
  };
}

function bookmarkListSchema() {
  return {
    type: 'object',
    properties: {
      query: { type: 'string' },
      author: { type: 'string' },
      after: { type: 'string', description: 'YYYY-MM-DD' },
      before: { type: 'string', description: 'YYYY-MM-DD' },
      category: { type: 'string' },
      domain: { type: 'string' },
      folder: { type: 'string' },
      limit: { type: 'number', minimum: 1, maximum: 100 },
      offset: { type: 'number', minimum: 0 },
    },
    additionalProperties: false,
  };
}

process.on('uncaughtException', (error) => {
  fs.writeSync(2, `field-theory MCP uncaught exception: ${error.stack || error.message}\n`);
});
